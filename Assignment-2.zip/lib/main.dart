import 'package:flutter/material.dart';
import 'birthDay.dart';

main() {
  runApp(MaterialApp(
    home: birthDay(),
  ));
}
