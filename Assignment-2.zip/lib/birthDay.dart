import 'package:flutter/material.dart';

class birthDay extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xffd618ca),
          title: Text('Birthday Card'),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/birth_day.jpg',
              height: 500,
            ),
            Text(
              'Happy Birthday!!',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w600,
              ),
            )
          ],
        ));
  }
}
